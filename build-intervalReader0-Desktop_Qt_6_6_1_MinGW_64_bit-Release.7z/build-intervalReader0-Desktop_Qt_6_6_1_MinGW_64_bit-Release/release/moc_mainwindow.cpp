/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.6.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../intervalReader0/mainwindow.h"
#include <QtCore/qmetatype.h>
#include <QtCore/QList>

#if __has_include(<QtCore/qtmochelpers.h>)
#include <QtCore/qtmochelpers.h>
#else
QT_BEGIN_MOC_NAMESPACE
#endif


#include <memory>

#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.6.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
QT_WARNING_DISABLE_GCC("-Wuseless-cast")
namespace {

#ifdef QT_MOC_HAS_STRINGDATA
struct qt_meta_stringdata_CLASSMainWindowENDCLASS_t {};
static constexpr auto qt_meta_stringdata_CLASSMainWindowENDCLASS = QtMocHelpers::stringData(
    "MainWindow",
    "removeButtonUnderSubMenu",
    "",
    "QMenu*",
    "parentMenu",
    "buttonName",
    "createRemoveSubMenu",
    "newProfile",
    "createLoadSubMenu",
    "handleNewSetup",
    "newProfileName",
    "readSerial",
    "openNewWindow",
    "deleteTextFile",
    "folderPath",
    "fileNameWithoutExtension",
    "implementProfile",
    "profilName",
    "setEqualColumnWidths",
    "QTableView*",
    "tableView",
    "setCellTextAlignment",
    "on_nextButton_clicked",
    "updateTableView",
    "QList<int>",
    "values",
    "row",
    "updateColumnLabels",
    "labels",
    "on_restartButton_clicked",
    "isTableViewFilled"
);
#else  // !QT_MOC_HAS_STRING_DATA
struct qt_meta_stringdata_CLASSMainWindowENDCLASS_t {
    uint offsetsAndSizes[62];
    char stringdata0[11];
    char stringdata1[25];
    char stringdata2[1];
    char stringdata3[7];
    char stringdata4[11];
    char stringdata5[11];
    char stringdata6[20];
    char stringdata7[11];
    char stringdata8[18];
    char stringdata9[15];
    char stringdata10[15];
    char stringdata11[11];
    char stringdata12[14];
    char stringdata13[15];
    char stringdata14[11];
    char stringdata15[25];
    char stringdata16[17];
    char stringdata17[11];
    char stringdata18[21];
    char stringdata19[12];
    char stringdata20[10];
    char stringdata21[21];
    char stringdata22[22];
    char stringdata23[16];
    char stringdata24[11];
    char stringdata25[7];
    char stringdata26[4];
    char stringdata27[19];
    char stringdata28[7];
    char stringdata29[25];
    char stringdata30[18];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_CLASSMainWindowENDCLASS_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_CLASSMainWindowENDCLASS_t qt_meta_stringdata_CLASSMainWindowENDCLASS = {
    {
        QT_MOC_LITERAL(0, 10),  // "MainWindow"
        QT_MOC_LITERAL(11, 24),  // "removeButtonUnderSubMenu"
        QT_MOC_LITERAL(36, 0),  // ""
        QT_MOC_LITERAL(37, 6),  // "QMenu*"
        QT_MOC_LITERAL(44, 10),  // "parentMenu"
        QT_MOC_LITERAL(55, 10),  // "buttonName"
        QT_MOC_LITERAL(66, 19),  // "createRemoveSubMenu"
        QT_MOC_LITERAL(86, 10),  // "newProfile"
        QT_MOC_LITERAL(97, 17),  // "createLoadSubMenu"
        QT_MOC_LITERAL(115, 14),  // "handleNewSetup"
        QT_MOC_LITERAL(130, 14),  // "newProfileName"
        QT_MOC_LITERAL(145, 10),  // "readSerial"
        QT_MOC_LITERAL(156, 13),  // "openNewWindow"
        QT_MOC_LITERAL(170, 14),  // "deleteTextFile"
        QT_MOC_LITERAL(185, 10),  // "folderPath"
        QT_MOC_LITERAL(196, 24),  // "fileNameWithoutExtension"
        QT_MOC_LITERAL(221, 16),  // "implementProfile"
        QT_MOC_LITERAL(238, 10),  // "profilName"
        QT_MOC_LITERAL(249, 20),  // "setEqualColumnWidths"
        QT_MOC_LITERAL(270, 11),  // "QTableView*"
        QT_MOC_LITERAL(282, 9),  // "tableView"
        QT_MOC_LITERAL(292, 20),  // "setCellTextAlignment"
        QT_MOC_LITERAL(313, 21),  // "on_nextButton_clicked"
        QT_MOC_LITERAL(335, 15),  // "updateTableView"
        QT_MOC_LITERAL(351, 10),  // "QList<int>"
        QT_MOC_LITERAL(362, 6),  // "values"
        QT_MOC_LITERAL(369, 3),  // "row"
        QT_MOC_LITERAL(373, 18),  // "updateColumnLabels"
        QT_MOC_LITERAL(392, 6),  // "labels"
        QT_MOC_LITERAL(399, 24),  // "on_restartButton_clicked"
        QT_MOC_LITERAL(424, 17)   // "isTableViewFilled"
    },
    "MainWindow",
    "removeButtonUnderSubMenu",
    "",
    "QMenu*",
    "parentMenu",
    "buttonName",
    "createRemoveSubMenu",
    "newProfile",
    "createLoadSubMenu",
    "handleNewSetup",
    "newProfileName",
    "readSerial",
    "openNewWindow",
    "deleteTextFile",
    "folderPath",
    "fileNameWithoutExtension",
    "implementProfile",
    "profilName",
    "setEqualColumnWidths",
    "QTableView*",
    "tableView",
    "setCellTextAlignment",
    "on_nextButton_clicked",
    "updateTableView",
    "QList<int>",
    "values",
    "row",
    "updateColumnLabels",
    "labels",
    "on_restartButton_clicked",
    "isTableViewFilled"
};
#undef QT_MOC_LITERAL
#endif // !QT_MOC_HAS_STRING_DATA
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_CLASSMainWindowENDCLASS[] = {

 // content:
      12,       // revision
       0,       // classname
       0,    0, // classinfo
      15,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       1,    2,  104,    2, 0x08,    1 /* Private */,
       6,    1,  109,    2, 0x08,    4 /* Private */,
       8,    1,  112,    2, 0x08,    6 /* Private */,
       9,    1,  115,    2, 0x08,    8 /* Private */,
      11,    0,  118,    2, 0x08,   10 /* Private */,
      12,    0,  119,    2, 0x08,   11 /* Private */,
      13,    2,  120,    2, 0x08,   12 /* Private */,
      16,    1,  125,    2, 0x08,   15 /* Private */,
      18,    1,  128,    2, 0x08,   17 /* Private */,
      21,    1,  131,    2, 0x08,   19 /* Private */,
      22,    0,  134,    2, 0x08,   21 /* Private */,
      23,    3,  135,    2, 0x08,   22 /* Private */,
      27,    2,  142,    2, 0x08,   26 /* Private */,
      29,    0,  147,    2, 0x08,   29 /* Private */,
      30,    1,  148,    2, 0x08,   30 /* Private */,

 // slots: parameters
    QMetaType::Void, 0x80000000 | 3, QMetaType::QString,    4,    5,
    QMetaType::Void, QMetaType::QString,    7,
    QMetaType::Void, QMetaType::QString,    7,
    QMetaType::Void, QMetaType::QString,   10,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString, QMetaType::QString,   14,   15,
    QMetaType::Void, QMetaType::QString,   17,
    QMetaType::Void, 0x80000000 | 19,   20,
    QMetaType::Void, 0x80000000 | 19,   20,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 19, 0x80000000 | 24, QMetaType::Int,   20,   25,   26,
    QMetaType::Void, 0x80000000 | 19, QMetaType::QStringList,   20,   28,
    QMetaType::Void,
    QMetaType::Bool, 0x80000000 | 19,   20,

       0        // eod
};

Q_CONSTINIT const QMetaObject MainWindow::staticMetaObject = { {
    QMetaObject::SuperData::link<QMainWindow::staticMetaObject>(),
    qt_meta_stringdata_CLASSMainWindowENDCLASS.offsetsAndSizes,
    qt_meta_data_CLASSMainWindowENDCLASS,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_CLASSMainWindowENDCLASS_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<MainWindow, std::true_type>,
        // method 'removeButtonUnderSubMenu'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QMenu *, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        // method 'createRemoveSubMenu'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        // method 'createLoadSubMenu'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        // method 'handleNewSetup'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        // method 'readSerial'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'openNewWindow'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'deleteTextFile'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        // method 'implementProfile'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        // method 'setEqualColumnWidths'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QTableView *, std::false_type>,
        // method 'setCellTextAlignment'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QTableView *, std::false_type>,
        // method 'on_nextButton_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'updateTableView'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QTableView *, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QList<int> &, std::false_type>,
        QtPrivate::TypeAndForceComplete<const int, std::false_type>,
        // method 'updateColumnLabels'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QTableView *, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QList<QString> &, std::false_type>,
        // method 'on_restartButton_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'isTableViewFilled'
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        QtPrivate::TypeAndForceComplete<QTableView *, std::false_type>
    >,
    nullptr
} };

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<MainWindow *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->removeButtonUnderSubMenu((*reinterpret_cast< std::add_pointer_t<QMenu*>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QString>>(_a[2]))); break;
        case 1: _t->createRemoveSubMenu((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 2: _t->createLoadSubMenu((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 3: _t->handleNewSetup((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 4: _t->readSerial(); break;
        case 5: _t->openNewWindow(); break;
        case 6: _t->deleteTextFile((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QString>>(_a[2]))); break;
        case 7: _t->implementProfile((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 8: _t->setEqualColumnWidths((*reinterpret_cast< std::add_pointer_t<QTableView*>>(_a[1]))); break;
        case 9: _t->setCellTextAlignment((*reinterpret_cast< std::add_pointer_t<QTableView*>>(_a[1]))); break;
        case 10: _t->on_nextButton_clicked(); break;
        case 11: _t->updateTableView((*reinterpret_cast< std::add_pointer_t<QTableView*>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QList<int>>>(_a[2])),(*reinterpret_cast< std::add_pointer_t<int>>(_a[3]))); break;
        case 12: _t->updateColumnLabels((*reinterpret_cast< std::add_pointer_t<QTableView*>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QList<QString>>>(_a[2]))); break;
        case 13: _t->on_restartButton_clicked(); break;
        case 14: { bool _r = _t->isTableViewFilled((*reinterpret_cast< std::add_pointer_t<QTableView*>>(_a[1])));
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = std::move(_r); }  break;
        default: ;
        }
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        switch (_id) {
        default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
        case 8:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 0:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< QTableView* >(); break;
            }
            break;
        case 9:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 0:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< QTableView* >(); break;
            }
            break;
        case 11:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 1:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< QList<int> >(); break;
            case 0:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< QTableView* >(); break;
            }
            break;
        case 12:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 0:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< QTableView* >(); break;
            }
            break;
        case 14:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 0:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< QTableView* >(); break;
            }
            break;
        }
    }
}

const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CLASSMainWindowENDCLASS.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 15)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 15;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 15)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 15;
    }
    return _id;
}
QT_WARNING_POP
